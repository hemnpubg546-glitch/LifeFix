package com.lifefix.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.content.Intent
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private fun bg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(9,12,20), Color.rgb(18,12,38))
    )
    private fun button(text:String): Button {
        val b=Button(this); b.text=text; b.setTextColor(Color.WHITE)
        b.textSize=15f; b.isAllCaps=false
        b.background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(35,210,255), Color.rgb(125,75,255))).apply{cornerRadius=28f}
        b.setPadding(25,0,25,0); return b
    }
    override fun onCreate(s:Bundle?) {
        super.onCreate(s)
        showHome()
    }
    private fun showHome() {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(28,30,28,20); root.background=bg()
        val logo=TextView(this); logo.text="LIFEFIX"; logo.setTextColor(Color.WHITE); logo.textSize=28f; logo.setTypeface(null,1)
        root.addView(logo, LinearLayout.LayoutParams(-1,70))
        val sub=TextView(this); sub.text="AI that helps you fix real-life problems."; sub.setTextColor(Color.LTGRAY); sub.textSize=15f
        root.addView(sub, LinearLayout.LayoutParams(-1,55))
        val title=TextView(this); title.text="What can we fix today?"; title.setTextColor(Color.WHITE); title.textSize=30f; title.setPadding(0,25,0,25)
        root.addView(title)
        val scan=button("📷  Scan a Problem"); scan.setOnClickListener {
            startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        }; root.addView(scan, LinearLayout.LayoutParams(-1,62))
        val talk=button("🎤  Describe by Voice"); talk.setOnClickListener { showInput() }
        val p=LinearLayout.LayoutParams(-1,62); p.topMargin=14; root.addView(talk,p)
        val type=button("✍️  Type a Problem"); type.setOnClickListener { showInput() }
        val p2=LinearLayout.LayoutParams(-1,62); p2.topMargin=14; root.addView(type,p2)
        val cats=TextView(this); cats.text="\nPopular fixes\n\n🏠 Home     📱 Tech     🚗 Car\n\n📚 Study     🔧 Repair     🍳 Cooking"
        cats.setTextColor(Color.WHITE); cats.textSize=16f; root.addView(cats)
        setContentView(root)
    }
    private fun showInput() {
        val box=EditText(this); box.hint="Tell LifeFix what is wrong…"; box.setTextColor(Color.WHITE); box.setHintTextColor(Color.GRAY)
        val layout=LinearLayout(this); layout.orientation=LinearLayout.VERTICAL; layout.setPadding(28,50,28,20); layout.background=bg()
        val t=TextView(this); t.text="Describe the problem"; t.setTextColor(Color.WHITE); t.textSize=27f; layout.addView(t)
        layout.addView(box, LinearLayout.LayoutParams(-1,180))
        val go=button("✨ Analyze with LifeFix"); go.setOnClickListener {
            Toast.makeText(this,"AI analysis will be connected next.",Toast.LENGTH_LONG).show()
        }; layout.addView(go, LinearLayout.LayoutParams(-1,62))
        val back=button("← Back"); back.setOnClickListener { showHome() }; val p=LinearLayout.LayoutParams(-1,62); p.topMargin=14; layout.addView(back,p)
        setContentView(layout)
    }
}
