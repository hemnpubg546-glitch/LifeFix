plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace="com.lifefix.app"; compileSdk=35
    defaultConfig { applicationId="com.lifefix.app"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" }
}
